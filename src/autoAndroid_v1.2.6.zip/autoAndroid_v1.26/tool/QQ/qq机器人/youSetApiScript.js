toast("qq机器人自定义接口脚本已开始运行");
log("qq机器人自定义接口脚本脚本已开始运行");
events.observeNotification();
events.on("notification", function(n) {

    var glob = 1;

    var information =
        "\r\n" +
        "时间戳:" + n.when + "\r\n" +
        "标题:" + n.getTitle() + "\r\n" +
        "内容:" + n.getText() + "\r\n" +
        "通知数量:" + n.number + "\r\n" +
        "包名:" + n.getPackageName() + "\r\n" +
        "\r\n";
    log(information);
    //判断是否为qq应用的通知
    if (n.getPackageName() == "com.tencent.mobileqq") {
                    //本地存储判断
                var storage = storages.create("youSetApi");
                var content = storage.get("youSetApi");
                
                //标题正确性判断
                var reg = new RegExp("^" +content.qqNick+".*", "gim");
                var is = reg.test(n.getTitle());
                if(is){
                //获取内容
                var text = n.getText().replace(/.*:/g, "");
                
              //  var qq_number=pubic_dispose_match(content, start_key);
              
                log(text);
                //请求接口
                var re=api(content.url,content.value1,text);
                log(re);
                //qq操作处理
                n.click();
                sleep(500);
              //  var key=content.key;
                qqYouSetApi(content.qqNick,content.tip+":\n"+re);
                }
                }
       });
                
                
//.请求接口函数
function api(url,key,value){
    res = http.get(url+"?&"+key+"="+value).body.string();
    log("返回数据:" + res);
    var data=res;
    //请求成功
    return data;//data;
}


//通知栏内容处理获取内容
function pubic_dispose_match(content, start_key) {

    /*
    参数:
    content:通知栏内容
    start_key:消息前缀关键词
    reg_data1:返回的提取处理数据(用于接口直接调用)
    *
    */
    //获取内容空格去除
    var content = content.replace(" ", "");
    log(content);
    //匹配前缀关键词后的内容
    var re = new RegExp(":.*", "gim");
    var data = content.match(re);
    log("数据:" + data);
    //判断是否含有开头start_key
    var reg = new RegExp("^:" + start_key, "gim");
    var is = reg.test(data);
    log("是否存在匹配项:" + is);
    if (is) {
        //开头存在start_key替换开头
        var data1 = data[0].replace(reg, "");
        return data1;
    } else {
        return 0;
    }
}

                

////匹配操作操作
function qqYouSetApi(qq, data){
    var count = 0;

    log("ok");
    while (true) {
        if (packageName("com.tencent.mobileqq").id("fun_btn").exists() == true && packageName("com.tencent.mobileqq").id("title").text(qq).exists() == true && packageName("com.tencent.mobileqq").id("fun_btn").exists() == true) {
            //发送答案
            input(data);
            id("fun_btn").findOne().click();
            //返回上一级
            back();
            sleep(400);
            back();

            //超时处理
            if (count == 300) {
                break;
            }
            break;
        }
    }
}
    
    
    
    
    
    
    
    
    
    