while(true){
var storage=storages.create("qq刷屏");
var content=storage.get("CI1");
var is=storage.get("is");
//整条发送
if(is===0){
log(content);

var t=id("fun_btn").exists();
if(t){
input(content);
id("fun_btn").findOne().click();
}else{
toast("请切换至聊天页面");
}
log(t);
}else{
//字符拆分发送
var item=content.split("");   //返回数组
log(item);
//遍历输出
for(var i=0;i<item.length;i++){

var t=id("fun_btn").exists();
if(t){
input(item[i]);
id("fun_btn").findOne().click();
}else{
toast("请切换至聊天页面");
}
}
}
}
