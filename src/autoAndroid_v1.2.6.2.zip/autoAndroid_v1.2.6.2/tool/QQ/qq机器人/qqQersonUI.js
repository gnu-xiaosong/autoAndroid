
"ui";
auto();
ui.layout(
    <vertical id="pay" padding="16">
         <text text="qq小号机器人设置" textColor="black" textSize="20sp" marginTop="16"/>
        
    <text text=""  textColor="black" textSize="16sp" marginTop="16"/>
         <!-- hint属性用来设置输入框的提示-->
         <text text="qq账号:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="person_qq" hint="输入完整的qq群昵称" text=""/>


         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="自定义查题开头搜索词:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="person_start" hint="输入自定义开头搜索词" text=""/>
         
          <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="自定义查题尾部广告:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="person_ad" hint="输入自定查题尾部广告" text=""/>
         
          <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="自定义添加成功的欢迎语:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="person_welcome" hint="自定义添加成功的欢迎语" text=""/>
         
         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="自定义备注前缀:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="person_qq_remarke" hint="自定义添加成功的欢迎语" text=""/>
         
         
         
         <horizontal >
         <vertical>
         <text text="图灵" textColor="black" gravity="center" textSize="20sp" marginTop="16"/>
        
        <checkbox id="cb2" checked="true" text=""/>
          </vertical>
          
            <vertical marginLeft="30dp">
        <text text="天气" textColor="black" gravity="center" textSize="20sp" marginTop="16"/>
        <checkbox id="weather" checked="true" text=""/>
          </vertical>
          
            <vertical marginLeft="30dp">
        <text text="qq吉凶" textColor="black" gravity="center" textSize="20sp" marginTop="16"/>
        <checkbox id="qqc" checked="true" text=""/>
          </vertical>
          
          <vertical marginLeft="30dp">
        <text text="热点" textColor="black" gravity="center" textSize="20sp" marginTop="16"/>
        <checkbox id="top" checked="true" text=""/>
          </vertical>
          
       <vertical marginLeft="30dp">
        <text text="词典" textColor="black" gravity="center" textSize="20sp" marginTop="16"/>
        <checkbox id="cy" checked="true" text=""/>
          </vertical>
        </horizontal>
        
        
        
        
         <horizontal>
         <button id="save" text="保存" w="auto" style="Widget.AppCompat.Button.Colored"/>
         <button id="monitor" marginLeft="150" text="启动监控" w="auto" style="Widget.AppCompat.Button.Colored"/>
         
         </horizontal>
                 <text maxLines="1" ellipsize="end" margin="8"></text>
                         <text maxLines="1" ellipsize="end" margin="8"></text>
        
        
                  <text textSize="20sp">注意事项:</text>

        <text textColor="#00ff00">1.注意将软件授权通知栏权限，否则无法使用</text>


        <text maxLines="1" ellipsize="end" margin="8">2.建议用自己的小号进行登陆qq</text>
        
        <text maxLines="1" ellipsize="end" margin="8">3.确保qq正常运行并且让qq获取通知栏通知权限</text>
             
        <text maxLines="1" ellipsize="end" margin="8">4.更多功能正在陆续开发中，尽请期待！</text>



    </vertical>
);

//storages.remove("qqBot_auto_person");

var storage=storages.create("qqBot_auto_person");

var data=storage.get("qqBot_auto_person");

log(data);
if(data){
//文本设置

ui.person_qq.setText(data.person_qq);

ui.person_start.setText(data.person_start);

ui.person_ad.setText(data.person_ad);

ui.person_welcome.setText(data.person_welcome);

ui.person_qq_remarke.setText(data.person_qq_remarke);
//数据页面渲染
}

//权限检测

alert("该功能需要操作手机，建议下载虚拟机vmos将该软件安装运行，启动即可");

//定义总的接口控制变量
var is=1;
var weather=1;
var qqc=1;
var top=1;
var cy=1;
ui.cb2.on("check", (checked)=>{
    if(checked){
    //开始自动图灵接口聊天
    is=1;
      //  toast("第一个框被勾选了");
    }else{
     is=0;
       // toast("第一个框被取消勾选了");
    }
});


//获取天气接口控制
ui.weather.on("check", (checked)=>{
    if(checked){
    //开始自动图灵接口聊天
    weather=1;
      //  toast("第一个框被勾选了");
    }else{
     weather=0;
       // toast("第一个框被取消勾选了");
    }
});

//获取成语词典接口控制
ui.cy.on("check", (checked)=>{
    if(checked){
    //开始自动图灵接口聊天
    cy=1;
      //  toast("第一个框被勾选了");
    }else{
     cy=0;
       // toast("第一个框被取消勾选了");
    }
});

//qq号码测吉凶控制
ui.qqc.on("check", (checked)=>{
    if(checked){
    //开始自动图灵接口聊天
    qqc=1;
      //  toast("第一个框被勾选了");
    }else{
     qqc=0;
       // toast("第一个框被取消勾选了");
    }
});

//qq号码测吉凶控制
ui.top.on("check", (checked)=>{
    if(checked){
    //开始自动图灵接口聊天
    top=1;
      //  toast("第一个框被勾选了");
    }else{
     top=0;
       // toast("第一个框被取消勾选了");
    }
});

//本地保存
ui.save.click(()=>{
      //创建一个名字为paySite的本地存储
var storage=storages.create("qqBot_auto_person");
//对象封装
var qqBot_auto_person={
    person_qq:ui.person_qq.text(),
    person_start:ui.person_start.text(),
    person_ad:ui.person_ad.text(),
    person_welcome:ui.person_welcome.text(),
    person_qq_remarke:ui.person_qq_remarke.text(),
    person_is:is,    //图灵机器人接口
    person_weather:weather,  //天气接口
    person_qqc:qqc ,  //qq号码测吉凶控制
    person_top:top , //热点新闻
    person_cy:cy    //成语
    };
//给该本地存储赋值
storage.put("qqBot_auto_person",qqBot_auto_person);
    toast("保存成功！");
log(storage.get("qqBot_auto_person"));
});
        
        
        
        
        
        
        
        
        
ui.monitor.click(()=>{
var path="./tool/QQ/qq机器人/qqQersonScript.js";
if(ui.monitor.getText() == '启动监控'){

       var execution = engines.execScriptFile(path);

        ui.monitor.setText('停止监控');
        toast("监控已启动……");
    }else{

        if(execution){

        //停止监控
            execution.getEngine().forceStop();

        }

        ui.monitor.setText('启动监控');
        toast("已停止监控");
    }
}
);
  


