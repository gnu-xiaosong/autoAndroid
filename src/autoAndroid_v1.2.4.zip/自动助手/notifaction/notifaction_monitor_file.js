//开始监听通知栏消息
events.observeNotification();
events.on("notification", function(n){
    var information=
    "时间戳:"+n.when+"\r\n"+
    "标题:"+n.getTitle()+"\r\n"+
    "内容:"+n.getText()+"\r\n"+
    "通知数量:"+n.number+"\r\n"+
    "包名:"+n.getPackageName()+"\r\n"+
    "\r\n";

    var path="/sdcard/notifaction.txt";
    if(!files.exists(path)){
    files.create(path);
    files.append(path, "通知状态栏信息:\r\n");
      }
    files.append(path, information);
    log(information);
   
});