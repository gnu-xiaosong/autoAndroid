auto();
var str;
var str1;
//启动通知栏监控
events.observeNotification();
events.on("notification", function(n){

    if(n.getTitle()!=null){
         if(n.getPackageName()=="com.eg.android.AlipayGphone"){
       
         str =n.getTitle();
        //通过正则判断提取
         str1=str.match(/你已成功收款(.*)元/); 
         if(str1!=null){
         //获取成功
         log(str1);
         log(str1[1]);
         //调用api
        var  response=payApi(str1[1]);
         /*response为对象类型 {
      "status":1,  //0为
      "message":"网络异常"
      };
         */
         //写进日志文件
           

         writeLog(response);
         toast("小松云支付:"+response);
         
          }
          
          }
    }else{
    log(n.getTitle());
    }
    log(n.getTitle()); 
});

//支付异步回调api
function payApi(money){
    //本地数据获取
    var storage=storages.create("pay");
    var data=storage.get("paySite");
    //接口地址
    var url=data.url;
    //传输内容
    var data1={
    "id": data.ID,
    "key": data.key,
    "money":money
      };
    //发起请求
    var res = http.get(url+"?id="+data1.id+"&key="+data1.key+"&money="+money);
    log(res.statusCode);
    //res响应判断
    if(res.statusCode == 404){
      
      return "网络异常或url有误！";
    }else if(res.statusCode >= 200 && res.statusCode < 300){
        //回调成功
       var resp=res.body.string();
       log(resp); 
       return resp;
    }else{
       return "未知异常";
  }
}






function writeLog(inform){
//获取当前时间
var date=new Date();
	//年
    var year=date.getFullYear();
    //月
    var month=date.getMonth()+1;
    //日
    var day=date.getDate();
    //时
    var hh=date.getHours();
    //分
    var mm=date.getMinutes();
    //秒
    var ss=date.getSeconds();
    var time=year+"年"+month+"月"+day+"日"+hh+":"+mm+":"+ss;

//订单编号 正则匹配
var order_no=inform.match(/\d+/i);
//服务器返回信息

    var information=
    "时间:"+time+"\r\n"+
    "订单编号:"+order_no+"\r\n"+
    "状态信息:"+inform+"\r\n"+
    "\r\n";

    var path="/sdcard/payLog.txt";
    if(!files.exists(path)){
    files.create(path);
    files.append(path, "软件监控服务器日志信息:\r\n");
      }
    files.append(path, information);
    log(information);
        
}