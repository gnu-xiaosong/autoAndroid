//开始监听通知栏消息
toast("通知栏监听启动");
console.show();
console.info("正在监听通知栏消息中……");
events.observeNotification();
events.on("notification", function(n){
    var information=
    "\r\n"+
    "时间戳:"+n.when+"\r\n"+
    "标题:"+n.getTitle()+"\r\n"+
    "内容:"+n.getText()+"\r\n"+
    "通知数量:"+n.number+"\r\n"+
    "包名:"+n.getPackageName()+"\r\n"+
    "\r\n";
    console.warn("正在监听通知栏消息中……");
    console.log(information);
});