//开始监听通知栏消息


//全局控制变量(0为默认关闭，1为默认开启)

toast("qq机器人自动答题脚本已开始运行");
log("qq机器人自动答题脚本已开始运行");
events.observeNotification();
events.on("notification", function(n) {

    var glob = 1;

    var information =
        "\r\n" +
        "时间戳:" + n.when + "\r\n" +
        "标题:" + n.getTitle() + "\r\n" +
        "内容:" + n.getText() + "\r\n" +
        "通知数量:" + n.number + "\r\n" +
        "包名:" + n.getPackageName() + "\r\n" +
        "\r\n";
    log(information);
    //判断是否为qq应用的通知
    if (n.getPackageName() == "com.tencent.mobileqq") {
    
                //是否开始图灵机器人聊天(开启)
                
                //获取内容
                var text = n.getText().replace(/.*:/g, "");

                //本地存储判断
                var storage = storages.create("qqAutoReplay");
                var content = storage.get("qqAutoReplay");
                log(text);
              
                if(JSON.parse(content[0]).keyword==text.toString()){
                var data2=JSON.parse(content[0]).replay;
                //操作
                n.click();
                log(data2);
                replay(content[6].nick, data2);
                }else if(content[1].keyword==text){
                var data2=content[1].replay;
                //操作
                n.click();
                log(data2);
                replay(content[6].nick, data2);
                }else if(content[2].keyword==text){
                var data2=content[2].replay;
                //操作
                n.click();
                log(data2);
                replay(content[6].nick, data2);
                }else if(content[3].keyword==text){
                var data2=content[3].replay;
                //操作
                n.click();
                log(data2);
                replay(content[6].nick, data2);
                }else if(content[4].keyword==text){
                var data2=content[4].replay;
                //操作
                n.click();
                log(data2);
                replay(content[6].nick, data2);
                }else if(content[5].keyword==text){
                var data2=content[5].replay;
                //操作
                n.click();
                log(data2);
                replay(content[6].nick, data2);
                }else if(content[6].keyword==text){
                var data2=content[6].replay;
                //操作
                n.click();
                log(data2);
                replay(content[6].nick, data2);
                }
            
                }
                });


////匹配操作操作
function replay(qq, data) {
    var count = 0;

    log("ok");
    while (true) {
        if (packageName("com.tencent.mobileqq").id("fun_btn").exists() == true && packageName("com.tencent.mobileqq").id("title").text(qq).exists() == true && packageName("com.tencent.mobileqq").id("fun_btn").exists() == true) {
            //发送答案
            input(data);
            id("fun_btn").findOne().click();
            //返回上一级
            back();
            sleep(400);
            back();

            //超时处理
            if (count == 300) {
                break;
            }
            break;
        }
    }
}
    
    
    
    
    
    
    
    
    
    
