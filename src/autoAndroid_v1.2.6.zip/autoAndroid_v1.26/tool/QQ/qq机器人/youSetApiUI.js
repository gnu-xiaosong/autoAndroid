
"ui";
auto();
ui.layout(
    <vertical id="pay" padding="16">
         <text text="qq机器人自定义接口配置" textColor="black" textSize="20sp" marginTop="16"/>
        
    <text text=""  textColor="black" textSize="16sp" marginTop="16"/>
         <!-- hint属性用来设置输入框的提示-->
         <text text="接口地址:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="url" hint="输入api的地址url" text=""/>

         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="GET参数字段名1:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="value1" hint="默认为get传参" text=""/>

         <!-- password属性用来设置输入框是否是密码输入框 -->
         <text text="GET参数字段名2:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="value2" hint="暂时不可用" password="false" text=""/>

<!-- password属性用来设置输入框是否是密码输入框 -->
         <text text="qq昵称:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="qqNick" hint="必填，填写与备注一样的" password="false" text=""/>

         <text text="返回数据提示词:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="tip" hint="必填，填写与备注一样的" password="false" text=""/>

         <text text="接口返回结果键值名:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="key" hint="暂时未开放，填写与备注一样的" password="false" text=""/>



         <horizontal>
         <button id="save" text="保存" w="auto" style="Widget.AppCompat.Button.Colored"/>
         <button id="monitor" marginLeft="150" text="启动监控" w="auto" style="Widget.AppCompat.Button.Colored"/>
         
         </horizontal>
                 <text maxLines="1" ellipsize="end" margin="8"></text>
                         <text maxLines="1" ellipsize="end" margin="8"></text>
        
        
                  <text textSize="20sp">注意事项:</text>

        <text textColor="#00ff00">1返回数据为json格式</text>


        <text maxLines="1" ellipsize="end" margin="8">2.确保是单一结果键值</text>
        
        <text maxLines="1" ellipsize="end" margin="8">id:商户id</text>
             
        <text maxLines="1" ellipsize="end" margin="8">key:商户密钥</text>
        
         <text maxLines="1" ellipsize="end" margin="8">money:隐藏自动获取支付宝金额参数</text>
        

    </vertical>
);

//storages.remove("youSetApi");
var storage=storages.create("youSetApi");

var data=storage.get("youSetApi");

if(data){
//文本设置
ui.url.setText(data.url);

ui.value1.setText(data.value1);

ui.value2.setText(data.value2);

ui.qqNick.setText(data.qqNick);

ui.tip.setText(data.tip);

ui.key.setText(data.key);
//数据页面渲染
}

//权限检测

alert("该功能需要您开启通知权限才能正常使用，并确保支付宝到账语音已打开");

//本地保存
ui.save.click(()=>{
      //创建一个名字为paySite的本地存储
var storage=storages.create("youSetApi");
//对象封装
var youSetApi={
    url:ui.url.text(),
    value1:ui.value1.text(),
    value2:ui.value2.text(),
    qqNick:ui.qqNick.text(),
    tip:ui.tip.text(),
    key:ui.key.text(),
    };
//给该本地存储赋值
storage.put("youSetApi",youSetApi);
    toast("保存成功！");
log(storage.get("youSetApi"));
});
        
        
ui.monitor.click(()=>{
    
var path="./tool/QQ/qq机器人/youSetApiScript.js";
if(ui.monitor.getText() == '启动监控'){

       var execution = engines.execScriptFile(path);

        ui.monitor.setText('停止监控');
        toast("监控已启动……");
    }else{

        if(execution){

        //停止监控
        execution.getEngine().forceStop();

        }

        ui.monitor.setText('启动监控');
        toast("已停止监控");
    }
}
);
  