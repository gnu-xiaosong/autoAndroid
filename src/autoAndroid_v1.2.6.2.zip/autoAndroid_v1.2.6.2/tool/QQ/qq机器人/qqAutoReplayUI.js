"ui";
auto();
ui.layout(
    <vertical id="pay" padding="16">
        <text text="qq机器人自定义回复配置" textColor="black" textSize="20sp" marginTop="16"/>
        
        <text text=""  textColor="black" textSize="16sp" marginTop="16"/>
        <!-- hint属性用来设置输入框的提示-->
        <text text="qq昵称:" textColor="black" textSize="16sp" marginTop="16"/>
        <input id="nick" hint="输入完整的qq昵称，注意要和你备注的名称相同" text=""/>
        
        <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
        <text text="qq号:" textColor="black" textSize="16sp" marginTop="16"/>
        <input id="qq" hint="输入qq群号，可选" text=""/>
        
        <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
        
        <horizontal>
            <button id="save" text="保存" w="auto" style="Widget.AppCompat.Button.Colored"/>
            <button id="monitor" marginLeft="150" text="启动监控" w="auto" style="Widget.AppCompat.Button.Colored"/>
        </horizontal>
        <text text="关键词回复" textColor="black" textSize="16sp" marginTop="16"/>
        
        
        
        
        
        <vertical>
            <horizontal>
                <vertical>
                    <text id="tt" textSize="16sp" textColor="#000000" text="关键词1: "/>
                    <input id="keyword1" hint="请输入关键词一" text=""/>
                </vertical>
                
                <vertical marginLeft="60dp">
                    <text id="tt" textSize="16sp" textColor="#000000" text="回复1: "/>
                    <input id="replay1" hint="请输入回复一" text=""/>
                </vertical>
            </horizontal>
            
            
            <horizontal>
                <vertical>
                    <text id="tt" textSize="16sp" textColor="#000000" text="关键词1: "/>
                    <input id="keyword2" hint="请输入关键词一" text=""/>
                </vertical>
                
                <vertical marginLeft="60dp">
                    <text id="tt" textSize="16sp" textColor="#000000" text="回复1: "/>
                    <input id="replay2" hint="请输入回复一" text=""/>
                </vertical>
            </horizontal>
            
            
            <horizontal>
                <vertical>
                    <text id="tt" textSize="16sp" textColor="#000000" text="关键词1: "/>
                    <input id="keyword3" hint="请输入关键词一" text=""/>
                </vertical>
                
                <vertical marginLeft="60dp">
                    <text id="tt" textSize="16sp" textColor="#000000" text="回复1: "/>
                    <input id="replay3" hint="请输入回复一" text=""/>
                </vertical>
            </horizontal>
            
            
            
            <horizontal>
                <vertical>
                    <text id="tt" textSize="16sp" textColor="#000000" text="关键词1: "/>
                    <input id="keyword4" hint="请输入关键词一" text=""/>
                </vertical>
                
                <vertical marginLeft="60dp">
                    <text id="tt" textSize="16sp" textColor="#000000" text="回复1: "/>
                    <input id="replay4" hint="请输入回复一" text=""/>
                </vertical>
            </horizontal>
            
            
            
            <horizontal>
                <vertical>
                    <text id="tt" textSize="16sp" textColor="#000000" text="关键词1: "/>
                    <input id="keyword5" hint="请输入关键词一" text=""/>
                </vertical>
                
                <vertical marginLeft="60dp">
                    <text id="tt" textSize="16sp" textColor="#000000" text="回复1: "/>
                    <input id="replay5" hint="请输入回复一" text=""/>
                </vertical>
            </horizontal>
            
            
            
            <horizontal>
                <vertical>
                    <text id="tt" textSize="16sp" textColor="#000000" text="关键词1: "/>
                    <input id="keyword6" hint="请输入关键词一" text=""/>
                </vertical>
                
                <vertical marginLeft="60dp">
                    <text id="tt" textSize="16sp" textColor="#000000" text="回复1: "/>
                    <input id="replay6" hint="请输入回复一" text=""/>
                </vertical>
            </horizontal>
            
        </vertical>
        
        
        <text maxLines="1" ellipsize="end" margin="8">
        </text>
        <text maxLines="1" ellipsize="end" margin="8">
        </text>
        
        
        <text textSize="20sp">注意事项:</text>
        
        <text textColor="#00ff00">1.注意将软件授权通知栏权限，否则无法使用</text>
        
        
        <text maxLines="1" ellipsize="end" margin="8">2.建议用自己的小号进行登陆qq</text>
        
        <text maxLines="1" ellipsize="end" margin="8">3.确保qq正常运行并且让qq获取通知栏通知权限</text>
        
        <text maxLines="1" ellipsize="end" margin="8">4.更多功能正在陆续开发中，尽请期待！</text>
        
        
    </vertical>

);

//storages.remove("qqAutoReplay");

var storage = storages.create("qqAutoReplay");

var data = storage.get("qqAutoReplay");
log(data);
if (data) {
    //数据页面渲染

    ui.keyword1.setText(data[0].keyword);
    ui.replay1.setText(data[0].replay);

    ui.keyword2.setText(data[1].keyword);
    ui.replay2.setText(data[1].replay);

    ui.keyword3.setText(data[2].keyword);
    ui.replay3.setText(data[2].replay);

    ui.keyword4.setText(data[3].keyword);
    ui.replay4.setText(data[3].replay);

    ui.keyword5.setText(data[4].keyword);
    ui.replay5.setText(data[4].replay);

    ui.keyword6.setText(data[5].keyword);
    ui.replay6.setText(data[5].replay);

    ui.nick.setText(data[6].nick);
    ui.qq.setText(data[6].qq);

}






//ui.list.setDataSource(storage.get("qqReplay"));

//本地保存
ui.save.click(() => {
    //创建一个名字为qqReplay的本地存储
    var storage = storages.create("qqAutoReplay");

    //数据封装
    var items2 = [{
            keyword: ui.keyword1.text(),
            replay: ui.replay1.text()
        },
        {
            keyword: ui.keyword2.text(),
            replay: ui.replay2.text()
        },
        {
            keyword: ui.keyword3.text(),
            replay: ui.replay3.text()
        },
        {
            keyword: ui.keyword4.text(),
            replay: ui.replay4.text()
        },
        {
            keyword: ui.keyword5.text(),
            replay: ui.replay5.text()
        },
        {
            keyword: ui.keyword6.text(),
            replay: ui.replay6.text()
        },
        {
            nick: ui.nick.text(),
            qq: ui.qq.text()
        },
    ];
    storage.put("qqAutoReplay", items2);
    toast("保存成功！");

    log(storage.get("qqAutoReplay"));
});









ui.monitor.click(() => {
    var path = "./tool/QQ/qq机器人/qqAutoReplayScript.js";
    if (ui.monitor.getText() == '启动监控') {

        var execution = engines.execScriptFile(path);

        ui.monitor.setText('停止监控');
        toast("监控已启动……");
    } else {

        if (execution) {

            //停止监控
            execution.getEngine().forceStop();

        }

        ui.monitor.setText('启动监控');
        toast("已停止监控");
    }
});