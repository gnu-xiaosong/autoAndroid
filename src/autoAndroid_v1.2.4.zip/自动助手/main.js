"ui";
auto();
//权限获取
runtime.requestPermissions(["android.permission.SYSTEM_ALERT_WINDOW"]);
importClass(android.graphics.Paint);
//提示
dialogs.build({
    title: "欢迎使用",
    content: "本软件由小松科技开发，\n主要特性:\n1.自动获取粘贴板内容并搜索答案\n2.内置丰富的题库接口\n3.悬浮窗显示，更加方便。\n4.命令行模式操作\n使用攻略:点击右下方+号图标即可启动",
    positive: "官方地址",
    negative: "知道了"
}).on("positive", ()=>{
    app.openUrl("http://www.xskj.store");
}).on("negative", ()=>{
    toast("欢迎！");
}).show();


var color = "#009688";

ui.layout(
    <drawer id="drawer">
        <vertical>
            <appbar>
                <toolbar id="toolbar" title="自动助手"/>
                <tabs id="tabs"/>
            </appbar>
            <viewpager id="viewpager">
                <frame>
                
                
               <linear orientation="vertical" h="*" w="*">
                //首页
        <card id="p1" w="*" h="100" margin="18"  padding="80" cardCornerRadius="15dp"
            cardElevation="1dp" gravity="center_vertical">
            <horizontal padding="18 8" h="auto">
                <text text="答题自动化" textColor="#222222" textSize="20sp"/>
                <text text="" textColor="#5c6bc0" textSize="9sp"/>
                <button id="t" marginLeft="150" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="进入" w="auto"/>
                 
            </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
        
                <card id="p1" w="*" h="100" margin="18"  padding="80" cardCornerRadius="15dp"
            cardElevation="1dp" gravity="center_vertical">
            <horizontal padding="18 8" h="auto">
                <text text="通知栏监听" textColor="#222222" textSize="20sp"/>
                <text text="" textColor="#5c6bc0" textSize="9sp"/>
                <button id="notifaction" marginLeft="150" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="进入" w="auto"/>
                 
            </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
        
         <card id="p1" w="*" h="100" margin="18"  padding="80" cardCornerRadius="15dp"
            cardElevation="1dp" gravity="center_vertical">
            <horizontal padding="18 8" h="auto">
                <text text="第三方支付监听" textColor="#222222" textSize="20sp"/>
                <text text="" textColor="#5c6bc0" textSize="9sp"/>
                <button id="pay" marginLeft="110" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="启动" w="auto"/>
                 
            </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
        
         <card id="p1" w="*" h="100" margin="18"  padding="80" cardCornerRadius="15dp"
            cardElevation="1dp" gravity="center_vertical">
            <horizontal padding="18 8" h="auto">
                <text text="QQ" textColor="#222222" textSize="20sp"/>
                <text text="" textColor="#5c6bc0" textSize="9sp"/>
                <button id="qq" marginLeft="200" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="进入" w="auto"/>
                 
            </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
              </linear>
   
                      <fab id="add" w="auto" h="auto" src="@drawable/ic_add_black_48dp"
            margin="16" layout_gravity="bottom|right" tint="#ffffff" />
                </frame>

                <frame>
                                  
        <list id="list">
            <vertical>
                <text id="name"textSize="20sp" textColor="red" text="{{name}}"/>
                <text id="content"  marginBottom="20sp" textSize="16sp" textColor="#000000" text="使用方法:{{content}}"/>
            </vertical>
        </list>
                </frame>
                <frame>
                    
                </frame>
                
            </viewpager>
        </vertical>
        <vertical layout_gravity="left" bg="#ffffff" w="280">
            <img w="280" h="200" scaleType="fitXY" src="http://images.shejidaren.com/wp-content/uploads/2014/10/023746fki.jpg"/>
            <list id="menu">
                <horizontal bg="?selectableItemBackground" w="*">
                    <img w="50" h="50" padding="16" src="{{this.icon}}" tint="{{color}}"/>
                    <text textColor="black" textSize="15sp" text="{{this.title}}" layout_gravity="center"/>
                </horizontal>
            </list>
        </vertical>
        
    </drawer>
);

var items = [
    {name: "自动答题", content: "占位"},
    {name: "状态栏监听", content: "占位"},
    {name: "第三方支付监听", content: "占位"},
    {name: "QQ", content: 21}
];

ui.list.setDataSource(items);




//pay monitor 支付监听
ui.pay.click(function(){
engines.execScriptFile("./pay/paySite.js");
});
ui.qq.click(function(){
autoQQ();
//engines.execScriptFile("./tool/qq.js");
});
//浮动按钮点击函数
ui.add.click(function(){
     engines.execScriptFile("./note.js");
     });  

 //通知栏点击函数
ui.notifaction.click(function(){
     notifaction();
     });  

//创建选项菜单(右上角)
ui.emitter.on("create_options_menu", menu=>{
    menu.add("设置");
    menu.add("关于");
});
//监听选项菜单点击
ui.emitter.on("options_item_selected", (e, item)=>{
    switch(item.getTitle()){
        case "设置":
            toast("还没有设置");
            break;
        case "关于":
            alert("关于", "Auto.js界面模板 v1.0.0");
            break;
    }
    e.consumed = true;
});
activity.setSupportActionBar(ui.toolbar);

//设置滑动页面的标题
ui.viewpager.setTitles(["首页", "使用教程", "个人中心"]);
//让滑动页面和标签栏联动
ui.tabs.setupWithViewPager(ui.viewpager);

//让工具栏左上角可以打开侧拉菜单
ui.toolbar.setupWithDrawer(ui.drawer);

ui.menu.setDataSource([
  {
      title: "开发者",
      icon: "@drawable/ic_android_black_48dp"
  },
  {
      title: "个人中心",
      icon: "@drawable/ic_settings_black_48dp"
  },
  {
      title: "随手记",
      icon: "@drawable/ic_favorite_black_48dp"
  },
  {
      title: "护眼模式",
      icon: "@drawable/ic_favorite_black_48dp"
  },
  {
      title: "退出",
      icon: "@drawable/ic_exit_to_app_black_48dp"
  }
]);

//自动答题页面跳转函数
ui.t.click(function(){
autoQu();
});


//通知栏监听
function notifaction(){
    ui.layout(
    <vertical>
        <appbar>
            <toolbar id="toolbar" title="通知栏监听"/>
        </appbar>
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
           <horizontal>
            <vertical padding="18 8" h="auto">
                <text text="消息监听记录" textColor="#222222" textSize="16sp"/>
                <text text="自动监听通知栏消息记录" textColor="#999999" textSize="10sp"/>
            </vertical>
            <spinner id="sp1" textSize="12" entries="模式选择|文件模式|控制台模式"/>
         <button id="select1" marginLeft="2" marginTop="50%" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="启动" w="auto"/>
          </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
        
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
           <horizontal>
            <vertical padding="18 8" h="auto">
                <text text="app类消息监听" textColor="#222222" textSize="16sp"/>
                <text text="qq自动回复，微信等" textColor="#999999" textSize="10sp"/>
            </vertical>
            <spinner id="sp2" textSize="12" entries="监听app|qq|微信"/>
         <button id="select2" marginLeft="18" marginTop="50%" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="启动" w="auto"/>
          </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
    </vertical>
);
//消息类记录
ui.select1.click(function(){
   var i=ui.sp1.getSelectedItemPosition();
   if(i==1){
   toast("通知栏消息监听记录已启动");
   //文件记录
   engines.execScriptFile("./notifaction/notifaction_monitor_file.js");
   }else if(i==2){
   //控制台模式
   engines.execScriptFile("./notifaction/notifaction_monitor_console.js");
   }else{
   alert("请选择模式！");
   }
});  
//app类监控
ui.select2.click(function(){
   var j=ui.sp2.getSelectedItemPosition();
   if(j==1){
   toast("通知栏消息监听记录已启动");
   //qq类
   engines.execScriptFile("./notifaction/qq.js");
   }else if(j==2){
   //微信
   engines.execScriptFile("./notifaction/wechat.js");
   }else{
   alert("请选择模式！");
   }
});  





}

//自动答题页面
function autoQu(){
    ui.layout(
    <vertical>
        <appbar>
            <toolbar id="toolbar" title="自动答题"/>
        </appbar>
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
           <horizontal>
            <vertical padding="18 8" h="auto">
                <text text="智慧树" textColor="#222222" textSize="16sp"/>
                <text text="多种模式答题" textColor="#999999" textSize="10sp"/>
            </vertical>
            <spinner id="sp1" marginLeft="45" textSize="12" entries="模式选择|手动模式|自动搜索|自动答题|配合小易|去除刷课弹窗"/>
         <button id="select2" marginLeft="2" marginTop="50%" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="启动" w="auto"/>
          </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
           <horizontal>
            <vertical padding="18 8" h="auto">
                <text text="学习通" textColor="#222222" textSize="16sp"/>
                <text text="多种模式答题" textColor="#999999" textSize="10sp"/>
            </vertical>
            <spinner id="sp3" marginLeft="45" textSize="12" entries="模式选择|手动模式|自动搜索|自动答题|配合小易"/>
         <button id="select3" marginLeft="2" marginTop="50%" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="启动" w="auto"/>
          </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
        
        
        
        
        
      
        
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
            <vertical padding="18 8" h="auto">
                <text text="学习通" textColor="#222222" textSize="16sp"/>
                <text text="多种应对场景" textColor="#999999" textSize="14sp"/>
            </vertical>
            <View bg="#ff5722" h="*" w="10"/>
        </card>
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
            <vertical padding="18 8" h="auto">
                <text text="自动监听操作类" textColor="#222222" textSize="16sp"/>
                <text text="自动签到，领金币，等" textColor="#999999" textSize="14sp"/>
            </vertical>
            <View bg="#4caf50" h="*" w="10"/>
        </card>
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
            <vertical padding="18 8" h="auto">
                <text text="待开发类" textColor="#222222" textSize="16sp"/>
                <text text="敬请期待……" textColor="#999999" textSize="14sp"/>
            </vertical>
            <View bg="#2196f3" h="*" w="10"/>
        </card>
    </vertical>
);

ui.select2.click(function(){
   var i=ui.sp1.getSelectedItemPosition();
   if(i==1){
   //手动模式
  engines.execScriptFile("./question/自动答题.js");
   }else if(i==2){
   //搜索模式
   engines.execScriptFile("./controller/智慧树/zhs.js");
   }else if(i==3){
    //自动模式
    alert("暂时未上线，敬请期待！");
   }else if(i==4){
   //配合学小易
   engines.execScriptFile("./controller/智慧树/xxy.js");
   }else if(i==5){
       //去除刷课弹窗
       engines.execScriptFile("./controller/智慧树/video.js");
   }else{
       alert("请选择模式！");
       }
});  


//学习通
ui.select3.click(function(){
   var i=ui.sp3.getSelectedItemPosition();
   if(i==1){
   //手动模式
  engines.execScriptFile("./question/自动答题.js");
   }else if(i==2){
   //页面搜索模式
   engines.execScriptFile("./controller/学习通/auto.js");
   }else if(i==3){
    //自动答题
    alert("暂时未上线，敬请期待！");
   }else if(i==4){
   //配合学小易
   engines.execScriptFile("./controller/学习通/xxy.js");
   }else{
       alert("请选择模式！");
       }
});  




}



//QQ业务
function autoQQ(){
    ui.layout(
    <vertical>
        <appbar>
            <toolbar id="toolbar" title="QQ业务"/>
        </appbar>
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
           <horizontal>
            <vertical padding="18 8" h="auto">
                <text text="QQ刷屏" textColor="#222222" textSize="16sp"/>
                <text text="多种刷屏模式" textColor="#999999" textSize="10sp"/>
            </vertical>

         <button id="select2" marginLeft="150" marginTop="50%" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="进入" w="auto"/>
          </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
        
        <card w="*" h="70" margin="10 5" cardCornerRadius="2dp"
            cardElevation="1dp" gravity="center_vertical">
           <horizontal>
            <vertical padding="18 8" h="auto">
                <text text="QQ机器人" textColor="#222222" textSize="16sp"/>
                <text text="你的掌上qq管家" textColor="#999999" textSize="10sp"/>
            </vertical>
            <spinner id="sp3" marginLeft="45" textSize="12" entries="模式选择|自动答题|自定义回复|自定义接口"/>
         <button id="select3" marginLeft="2" marginTop="50%" textSize="10sp" style="Widget.AppCompat.Button.Colored" text="启动" w="auto"/>
          </horizontal>
            <View bg="#f44336" h="*" w="10"/>
        </card>
    </vertical>
);

ui.select2.click(function(){
   engines.execScriptFile("./tool/qq_control.js");
});  


//学习通
ui.select3.click(function(){
   var i=ui.sp3.getSelectedItemPosition();
   if(i==1){
   //qq自动答题模式
  engines.execScriptFile("./tool/QQ/qq机器人自动答题/qq机器人自动答题.js");
   }else if(i==2){
   //qq机器人关键词自动回复
   engines.execScriptFile("./tool/QQ/qq机器人自动答题/qqBotKeyRe.js");
   }else if(i==3){
    //自动答题
    alert("暂时未上线，敬请期待！");
   }else if(i==4){
   //配合学小易
   engines.execScriptFile("./controller/学习通/xxy.js");
   }else{
       alert("请选择模式！");
       }
});  




}






