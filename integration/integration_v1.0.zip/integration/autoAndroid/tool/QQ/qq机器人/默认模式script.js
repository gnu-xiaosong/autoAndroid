//开始监听通知栏消息


//全局控制变量(0为默认关闭，1为默认开启)

toast("qq机器人自动答题脚本已开始运行");
log("qq机器人自动答题脚本已开始运行");
events.observeNotification();
events.on("notification", function(n) {

    var glob = 1;

    var information =
        "\r\n" +
        "时间戳:" + n.when + "\r\n" +
        "标题:" + n.getTitle() + "\r\n" +
        "内容:" + n.getText() + "\r\n" +
        "通知数量:" + n.number + "\r\n" +
        "包名:" + n.getPackageName() + "\r\n" +
        "\r\n";
    log(information);
    //判断是否为qq应用的通知
    if (n.getPackageName() == "com.tencent.mobileqq") {
        //获取配置信息中qq群名
        var storage = storages.create("qqBot_auto");
        var data = storage.get("qqBot_auto");
        //  log(data);
        //  log("图灵是否开始:"+data.is);
        //正则匹配
        var re = new RegExp("^" + data.name + ".*", "gim");
        //  log(data.name);
        //字符切割
        var title = n.getTitle();

        var is = re.test(title);
        log("标题匹配结果:" + is);
        //判断标题为qq群名
        if (is) {
            //正则匹配
            //  log("内容为:");
            var content = n.getText().replace(" ", "");
            // log(content);

            var data1 = dispose_match(content, data);

            //控制匹配字段


            if (data1 != null) {

                //连接题库接口查询

                log(data1);
                //匹配成功，执行接口调用函数获取答案
                var ret = getData(data1);
                log(ret.question);

                //提交到数据库中
                submitData(ret);

                //自动化操作自动回复

                //点击进入qq聊天页面
                n.click();
                sleep(500);
                //执行
                qq(data.name, ret,data.ad); //传入qq名称和答案回复
            }




            //天气接口
            if (data.weather == 1 && data1 == null) {
                //消息前缀
                var start_key = "天气";
                //通知栏内容
                var content = n.getText();

                //天气接口
                var rey = pubic_dispose_match(content, start_key);
                if (rey != 0) {


                    //改变全局控制变量
                    glob = 0;
                    log("处理后数据:" + rey);
                    //存在开头关键词执行接口请求
                    var dataWeather = getWeather(rey);
                    log(dataWeather);
                    //数据判断
                    if (dataWeather == null) {
                        var reData = "请输入正确的城市名！";
                        n.click();
                        QQ(data.name, reData);
                    } else {
                        //回复数据封装
                        var reData = "城市:" + dataWeather.city + "\n" + "今天:\n" + "温度:" + dataWeather.realtime.temperature + "摄氏度" + "\n" + "湿度:" + dataWeather.realtime.humidity + "\n" + "天气状况:" + dataWeather.realtime.info + "\n" + "风向:" + dataWeather.realtime.direct + "\n" + "风力:" + dataWeather.realtime.power + "\n" + "空气指数:" + dataWeather.realtime.aqi;
                        //点击进入qq
                        n.click();
                        //qq自动回复操作
                        QQ_weather(data.name, reData);
                        //未来天气遍历
                        for (let i = 0; i < dataWeather.future.length; i++) {
                            log(dataWeather.future[i]);
                            var future = "未来天气:\n" + "日期:" + dataWeather.future[i].date + "\n" +
                                "温度:" + dataWeather.future[i].temperature + "\n" +
                                "天气:" + dataWeather.future[i].weather + "\n" + "风向:" + dataWeather.future[i].direct;
                            QQ_weather(data.name, future);
                        }
                        back();
                        sleep(400);
                        back();
                    }

                }
            }

           
           
           
           //QQ号码测吉凶
           if(data.qqc == 1 && data1 == null&&glob==1) {
               //消息前缀
                var start_key = "QQ";
                //通知栏内容
                var content = n.getText();
                //获取匹配值数据
                var qq_number=pubic_dispose_match(content, start_key);
                if(qq_number!=0){
                //存在关键词
                //改变全局控制变量值
                  glob=0;
                  //请求数据
                  var dataqq=api("qq",qq_number);
                  log(dataqq);
                  if(dataqq==null){
                     var qqReData = "未能查询到！";
                        n.click();
                        QQ(data.name, qqReData);
                  }else{
                  //查询到了
                  var qqcData="结果:\nQQ号码测试结论:"+dataqq.data.conclusion+"\n"+"寓意:"+dataqq.data.analysis;
                   //操作qq
                   n.click();
                   //qq自动回复操作
                    QQ(data.name, qqcData);
                  }
                }

            }
            
            
            //头条热点新闻接口
           if(data.top== 1 && data1 == null&&glob==1) {
               //消息前缀
                var start_key_top = "热点";
                //通知栏内容
                var content_top = n.getText();
                //获取匹配值数据
                var top_data=pubic_dispose_match(content_top, start_key_top);
                
                if(top_data!=0){
                //全局变量控制
                glob=0;
                var title;
                //值判断
                if(top_data=="社会"){
                top_data="shehui";
                title="社会";
                }else if(top_data=="国内"){
                top_data="guonei";
                title="国内";
                }else if(top_data=="娱乐"){
                top_data="yule";
                title="娱乐";
                }else if(top_data=="科技"){
                top_data="keji";
                title="科技";
                }else if(top_data=="体育"){
                top_data="tiyu";
                title="体育";
                }else if(top_data=="军事"){
                top_data="junshi";
                title="军事";
                }else if(top_data=="财经"){
                top_data="caijing";
                title="财经";
                }else if(top_data=="时尚"){
                top_data="shishang";
                title="时尚";
                }else{
                //默认top
                top_data="top";
                }
                  //请求数据
                  var dataqq=apiTop("type",top_data);
                  log(dataqq);
                  
                  //数据封装
                  var topData=title+"TOP10\n";
                  for(var i=0;i<dataqq.length;i++){
                  topData+="\n标题:"+dataqq[i].title+"\n时间:"+dataqq[i].date+"\n链接:"+dataqq[i].url+dataqq[i].uniquekey+"\n";
                  }
                  log(topData);
                  
                  
                  
                   //操作qq
                   n.click();
                   //qq自动回复操作
                   QQ(data.name, topData);
                  }
                  
            }
            
            
            
            
          //成语词典接口
           if(data.cy== 1 && data1 == null&&glob==1) {
               //消息前缀
                var start_key_cy = "成语";
                //通知栏内容
                var content_cy= n.getText();
                //获取匹配值数据
                var cy_data=pubic_dispose_match(content_cy, start_key_cy);
                
                if(cy_data!=0){
                //全局变量控制
                log("这里"+cy_data);
                glob=0;

                  //请求数据
                  var dataCy=apiCy("word",cy_data);
                  log(dataCy);
                   
                 if(dataCy!=null){
                  //数据封装
                  cyData="查询结果:\n部首:"+dataCy.bushou+"\n上部:"+dataCy.head+"\n拼音:"+dataCy.pinyin+"\n成语解释:"+dataCy.chengyujs+"\n出自"+dataCy.from_+"\n例子:"+dataCy.example+"\n用法:"+dataCy.yufa+"\n词语解释:"+dataCy.ciyujs+"\n解释:"+dataCy.yinzhengjs+"\n同义词:"+dataCy.tongyi+"\n反义词:"+dataCy.fanyi;
                  }else{
                  cyData="查询不到该成语的相关信息"
                  }
                   //操作qq
                   n.click();
                   //qq自动回复操作
                   QQ(data.name, cyData);
                  }
                  
            }
            
            
            
            
            
            
            
            
            
            //是否开始图灵机器人聊天(开启)
            if (data.is == 1 && data1 == null && glob == 1) {

                //获取内容
                var text = n.getText().replace(/.*:/g, "");
                var t = getDataTu(text);
                log(t.text);
                //操作
                n.click();
                tuling(data.name, t.text);
                //正常聊天
            }










        }
    }

});


//qq自动操作回复函数天气接口
function QQ_weather(qq, data) {

    /*
    参数:
    qq:通知栏内容
    data:发送的qq内容
    *
    */
    var count = 0;
    log("ok");
    while (true) {
        if (packageName("com.tencent.mobileqq").id("fun_btn").exists() == true && packageName("com.tencent.mobileqq").id("title").text(qq).exists() == true && packageName("com.tencent.mobileqq").id("fun_btn").exists() == true) {
            //发送答案
            input(data);
            id("fun_btn").findOne().click();
            //超时处理
            if (count == 300) {
                break;
            }
            break;
        }
    }
}





//qq自动操作回复函数
function qq(qq, data,ad) {
    var count = 0;
    log("ok");
    while (true) {
        if (packageName("com.tencent.mobileqq").id("fun_btn").exists() == true && packageName("com.tencent.mobileqq").id("title").text(qq).exists() == true && packageName("com.tencent.mobileqq").id("fun_btn").exists() == true) {
            //发送答案
            input("[题目]:" + data.question + "\n" + "[答案]" + data.answer + ad);
            id("fun_btn").findOne().click();
            //返回上一级
            back();
            sleep(400);
            back();

            //超时处理
            if (count == 300) {
                break;
            }
            break;
        }
    }
}



//qq自动操作回复函数
function QQ(qq, data) {

    /*
    参数:
    qq:通知栏内容
    data:发送的qq内容
    *
    */
    var count = 0;
    log("ok");
    while (true) {
        if (packageName("com.tencent.mobileqq").id("fun_btn").exists() == true && packageName("com.tencent.mobileqq").id("title").text(qq).exists() == true && packageName("com.tencent.mobileqq").id("fun_btn").exists() == true) {
            //发送答案
            input(data);
            id("fun_btn").findOne().click();
            //返回上一级
            back();
            sleep(400);
            back();

            //超时处理
            if (count == 300) {
                break;
            }
            break;
        }
    }
}




//图灵机器人操作
function tuling(qq, data) {
    var count = 0;

    log("ok");
    while (true) {
        if (packageName("com.tencent.mobileqq").id("fun_btn").exists() == true && packageName("com.tencent.mobileqq").id("title").text(qq).exists() == true && packageName("com.tencent.mobileqq").id("fun_btn").exists() == true) {
            //发送答案
            input(data);
            id("fun_btn").findOne().click();
            //返回上一级
            back();
            sleep(400);
            back();

            //超时处理
            if (count == 300) {
                break;
            }
            break;
        }
    }
}


//通知栏内容处理获取内容
function pubic_dispose_match(content, start_key) {

    /*
    参数:
    content:通知栏内容
    start_key:消息前缀关键词
    reg_data1:返回的提取处理数据(用于接口直接调用)
    *
    */
    //获取内容空格去除
    var content = content.replace(" ", "");
    log(content);
    //匹配前缀关键词后的内容
    var re = new RegExp(":.*", "gim");
    var data = content.match(re);
    log("数据:" + data);
    //判断是否含有开头start_key
    var reg = new RegExp("^:" + start_key, "gim");
    var is = reg.test(data);
    log("是否存在匹配项:" + is);
    if (is) {
        //开头存在start_key替换开头
        var data1 = data[0].replace(reg, "");
        return data1;
    } else {
        return 0;
    }
}








//正则处理
function dispose_match(data1, data) {
    //字符处理
    var re = new RegExp(":" + data.start + ".*", "gim");
    var data2 = data1.match(re);

    if (data2 == null) {
        return null;
    }

    //log(data2[0]);
    var reg = new RegExp(":" + data.start + "(.*?)", "gim");

    log(reg);
    var data3 = data2[0];
    var reg_data = data3.match(reg);
    //除去前缀
    var reg_data1 = data3.replace(reg_data[0], "");
    //log("匹配结果信息:"+reg_data);
    //log(reg_data1);
    return reg_data1;
}













//题库搜索
function getData(data1) {
    let url = "https://api.wkdnb.cn/935811140.php?";
    //传输内容
    let data = {
        "tm": data1
    };
    res = http.get(url + "tm=" + data.tm).body.json();
    log("结果:" + res);

    return eval(res);
}

//图灵机器人接口
function getDataTu(data1) {
    let url = "http://www.tuling123.com/openapi/api?key=68ce14a045af4c65b2fe89a9efc79a66";
    //传输内容
    let data = {
        "info": data1 //输入内容
    };
    res = http.get(url + "&info=" + data.info).body.json();
    log("结果:" + res);

    return eval(res);
}


//获取qq测吉凶接口数据
function api(key,value){
    res = http.get("http://japi.juhe.cn/qqevaluate/qq?key=41f89ac0eac08fb7dbd9cd41e0e7171e&"+key+"="+value).body.json();
    log("返回数据:");
    log(res);
    var data = eval(res);

    //请求成功
    return data.result;
}


//.获取头条热点
function apiTop(key,value){
    res = http.get("http://v.juhe.cn/toutiao/index?key=41559ed9d2d7f3657ef5815ba342cd8e&"+key+"="+value).body.json();
    log("返回数据:" + res);
    var data = eval(res);

    //请求成功
    return data.result.data;
}


//.获取成语词典接口
function apiCy(key,value){
    res = http.get("http://v.juhe.cn/chengyu/query?key=fb68915734a02cf587e2a05c5c193f27&"+key+"="+value).body.json();
    log("返回数据:" + res);
    var data = eval(res);

    //请求成功
    return data.result;
}





//获取天气方法
function getWeather(city) {
    res = http.get("http://apis.juhe.cn/simpleWeather/query?key=705b706791402e4ad20f59efc4c87d35" + "&city=" + city).body.json();
    log("返回数据:" + res);
    var data = eval(res);

    //请求成功
    return data.result;
}



//提交题库资源到数据库
function submitData(data) {
    /*参数提示
    *data={
    problem:
    answer:
    }
    *
    */
    var data = {
        problem: data.question,
        answer: data.answer
    }
    //提交到题库资源数据库
    res = http.get("http://api.xskj.store/index.php/app?q=" + data.problem + "&a=" + data.answer);
    log("提交状态:" + res.statusCode);
}