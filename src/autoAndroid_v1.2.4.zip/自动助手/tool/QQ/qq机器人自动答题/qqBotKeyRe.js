
"ui";
auto();
ui.layout(

    <vertical id="pay" padding="16">
         <text text="qq机器人自定义回复配置" textColor="black" textSize="20sp" marginTop="16"/>

    <text text=""  textColor="black" textSize="16sp" marginTop="16"/>
         <!-- hint属性用来设置输入框的提示-->
         <text text="qq昵称:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="name" hint="输入完整的qq昵称，注意要和你备注的名称相同" text=""/>

         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="qq号:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="qq" hint="输入qq群号，可选" text=""/>

         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->

         <horizontal>
         <button id="save" text="保存" w="auto" style="Widget.AppCompat.Button.Colored"/>
         <button id="monitor" marginLeft="150" text="启动监控" w="auto" style="Widget.AppCompat.Button.Colored"/>
         </horizontal>
         <text text="关键词回复" textColor="black" textSize="16sp" marginTop="16"/>
         <list id="list">
            <vertical>
                <text id="name" textSize="16sp" textColor="#000000" text="姓名: {{name}}"/>
                <text id="age" textSize="16sp" textColor="#000000" text="年龄: {{age}}岁"/>
                <button id="deleteItem" text="删除"/>
            </vertical>
          </list>

            <text maxLines="1" ellipsize="end" margin="8"></text>
                         <text maxLines="1" ellipsize="end" margin="8"></text>
        
        
                  <text textSize="20sp">注意事项:</text>

        <text textColor="#00ff00">1.注意将软件授权通知栏权限，否则无法使用</text>


        <text maxLines="1" ellipsize="end" margin="8">2.建议用自己的小号进行登陆qq</text>
        
        <text maxLines="1" ellipsize="end" margin="8">3.确保qq正常运行并且让qq获取通知栏通知权限</text>
             
        <text maxLines="1" ellipsize="end" margin="8">4.更多功能正在陆续开发中，尽请期待！</text>
        

    </vertical>

);

//storages.remove("qqBot_auto");

var items2 = [
    {name: "小明", age: 18}, {name: "小红", age: 30},
    {name: "小东", age: 19}, {name: "小强", age: 31},
    {name: "小满", age: 20}, {name: "小一", age: 32},
    {name: "小和", age: 21}, {name: "小二", age: 1},
    {name: "小贤", age: 22}, {name: "小三", age: 2},
    {name: "小伟", age: 23}, {name: "小四", age: 3},
    {name: "小黄", age: 24}, {name: "小五", age: 4},
    {name: "小健", age: 25}, {name: "小六", age: 5},
    {name: "小啦", age: 26}, {name: "小七", age: 6},
    {name: "小哈", age: 27}, {name: "小八", age: 7},
    {name: "小啊", age: 28}, {name: "小九", age: 8},
    {name: "小啪", age: 29}, {name: "小十", age: 9}
];

ui.list.setDataSource(items2);





        
        
        
        
        
        
ui.monitor.click(()=>{
var path="./tool/QQ/qq机器人自动答题/qqBotKeyReScript.js";
if(ui.monitor.getText() == '启动监控'){

       var execution = engines.execScriptFile(path);

        ui.monitor.setText('停止监控');
        toast("监控已启动……");
    }else{

        if(execution){

        //停止监控
            execution.getEngine().forceStop();

        }

        ui.monitor.setText('启动监控');
        toast("已停止监控");
    }
}
);
  



