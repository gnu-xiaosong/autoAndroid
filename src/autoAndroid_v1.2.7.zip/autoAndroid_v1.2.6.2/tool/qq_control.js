
"ui";
ui.layout(
    <vertical id="pay" padding="16">
         <text text="qq刷屏工具" textColor="black" textSize="20sp" marginTop="16"/>
        
 <text text=""  textColor="black" textSize="16sp" marginTop="16"/>
         <!-- hint属性用来设置输入框的提示-->
         <text text="对方qq:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="qq" hint="暂时不填" text=""/>

         <spinner id="sp1" w="150" textSize="20" entries="模式选择|刷词模式|刷图模式"/>

         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="刷屏词:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="ci" hint="输入要刷屏的词，可选" text=""/>
         <spinner id="is" w="150" textSize="20" entries="刷词方式|整条发送|逐字发送"/>

         
       <horizontal>
         <text text="" textColor="black" textSize="16sp" marginTop="16"/>
         <button id="save" text="开始刷屏" marginTop="100" marginLeft="100" w="150" style="Widget.AppCompat.Button.Colored"/>
         </horizontal>
    </vertical>
);


alert("请不要恶意刷屏，以防被踢！");
ui.save.click(()=>{
      //创建一个名字为paySite的本地存储
var storage=storages.create("qq刷屏");
//对象封装
var qq=ui.ci.text();
//给该本地存储赋值
storage.put("CI1",qq);
//权限检测
});     

ui.save.click(function(){
    var j=ui.is.getSelectedItemPosition();
    if(j==1){
    //整条
       var storage=storages.create("qq刷屏");
       storage.put("is",0);
    }else if(j==2){
    //逐字
       var storage=storages.create("qq刷屏");
       storage.put("is",1);
    }else{
    alert("请选择模式！");
    }

});

toast("保存成功！");
        
        
    //本地保存

//选择
ui.save.click(function(){
    var i=ui.sp1.getSelectedItemPosition();
    if(i==1){
    //刷词
       engines.execScriptFile("./tool/QQ/刷词control.js");
    }else if(i==2){
    //刷图
       engines.execScriptFile("./tool/QQ/刷图control.js");
    }else{
    alert("请选择模式！");
    }

});