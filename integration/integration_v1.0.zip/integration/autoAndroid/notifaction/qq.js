//信息配置页面
"ui";
ui.layout(
    <vertical padding="16">
         <text text="QQ消息监控配置" textColor="black" textSize="20sp" marginTop="16"/>
        
 <text text="" textColor="black" textSize="16sp" marginTop="16"/>
         <!-- hint属性用来设置输入框的提示-->
         <text text="QQ昵称:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="nickName" text="" hint="请输入你给对方的备注或对方昵称"/>

         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="监控内容关键字:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="keyword" text="" hint="不填，暂时不支持" text=""/>

         <!-- password属性用来设置输入框是否是密码输入框 -->
         <text text="自定义回复:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="content" text="" hint="输入对方发消息后回复词"/>

         <!-- lines属性用来设置输入框的行数 -->
         <text text="响应类型:" textColor="black" textSize="16sp" marginTop="16"/>
         <spinner id="responseType" text="" w="200" entries="跳转页面|自动回复|播放音乐提醒"/>

         <text text="对方qq号:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="qq" text="" hint="可选"/>
         <button id="ok" text="保存并启动" w="auto" style="Widget.AppCompat.Button.Colored"/>
    </vertical>
);
//必填字段验证
ui.ok.click(()=>{
    var text = ui.nickName.text();
    if(text.length == 0){
        ui.nickName.setError("输入不能为空");
        return;
    }
    var nickName = parseInt(text);
    if(qq < 10000){
        ui.nickName.setError("QQ号码格式错误");
        return;
    }
    ui.nickName.setError(null);
});

var data=new Object();
data.nickName=ui.nickName.text();
data.keyword=ui.keyword.text();
data.content=ui.content.text();
data.responseType=ui.responseType.text();
data.qq=ui.qq.text();
log(data);
//启动监控
//开始监听通知栏消息
toast("通知栏监听qq启动");
events.on("notification", function(n){
   //监听操作
   if(n.getPackageName()=="com.tencent.mobileqq"){
   toast("这是qq应用");
   //对qq对象进行操作
   
   }else{
   toast("监听失败");
   }

});













