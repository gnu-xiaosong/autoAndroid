id("gnt").findOne().click();
while(true){
var is=id("gnt").exists();
if(is){
sleep(500);
click(310,1462);

id("fun_btn").findOne().click();
}else{
toast("请切换至聊天页面");
}


}
