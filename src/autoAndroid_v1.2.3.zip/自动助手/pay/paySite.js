
"ui";
auto();
ui.layout(
    <vertical id="pay" padding="16">
         <text text="第三方支付监控配置信息" textColor="black" textSize="20sp" marginTop="16"/>
        
    <text text=""  textColor="black" textSize="16sp" marginTop="16"/>
         <!-- hint属性用来设置输入框的提示-->
         <text text="监听地址:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="url" hint="输入监听的地址url" text=""/>

         <!-- inputType属性用来设置输入类型，包括number, email, phone等-->
         <text text="商户ID:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="id" hint="商户ID" text=""/>

         <!-- password属性用来设置输入框是否是密码输入框 -->
         <text text="商户秘钥:" textColor="black" textSize="16sp" marginTop="16"/>
         <input id="key" hint="商户秘钥" password="true" text=""/>


         <horizontal>
         <button id="save" text="保存" w="auto" style="Widget.AppCompat.Button.Colored"/>
         <button id="monitor" marginLeft="150" text="启动监控" w="auto" style="Widget.AppCompat.Button.Colored"/>
         
         </horizontal>
                 <text maxLines="1" ellipsize="end" margin="8"></text>
                         <text maxLines="1" ellipsize="end" margin="8"></text>
        
        
                  <text textSize="20sp">接口文档:</text>

        <text textColor="#00ff00">method:GET</text>


        <text maxLines="1" ellipsize="end" margin="8">提交参数:</text>
        
        <text maxLines="1" ellipsize="end" margin="8">id:商户id</text>
             
        <text maxLines="1" ellipsize="end" margin="8">key:商户密钥</text>
        
         <text maxLines="1" ellipsize="end" margin="8">money:隐藏自动获取支付宝金额参数</text>
        

    </vertical>
);

var storage=storages.create("pay");

var data=storage.get("paySite");

if(data){
//文本设置

ui.url.setText(data.url);

ui.id.setText(data.ID);

ui.key.setText(data.key);

//数据页面渲染
}

//权限检测

alert("该功能需要您开启通知权限才能正常使用，并确保支付宝到账语音已打开");

//本地保存
ui.save.click(()=>{
      //创建一个名字为paySite的本地存储
var storage=storages.create("pay");
//对象封装
var paySite={
    url:ui.url.text(),
    ID:ui.id.text(),
    key:ui.key.text()
    };
//给该本地存储赋值
storage.put("paySite",paySite);
    toast("保存成功！");
log(storage.get("paySite"));
});
        
        
ui.monitor.click(()=>{
    
var path="./pay/monitor.js";
if(ui.monitor.getText() == '启动监控'){

       var execution = engines.execScriptFile(path);

        ui.monitor.setText('停止监控');
        toast("监控已启动……");
    }else{

        if(execution){

        //停止监控
            execution.getEngine().forceStop();

        }

        ui.monitor.setText('启动监控');
        toast("已停止监控");
    }
}
);
  